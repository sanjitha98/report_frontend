import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import React from "react";
// import { useSelector } from "react-redux";
const Login = React.lazy(() =>
  import(/* webpackPrefetch: true */ "./component/Login")
);
const Dashboard = React.lazy(() =>
  import(/* webpackPrefetch: true */ "./component/Dashboard")
);
const ForgotPassword = React.lazy(() =>import(/* webpackPrefetch: true */ "./component/ForgotPassword"));
const ResetPassword = React.lazy(() =>import(/* webpackPrefetch: true */ "./component/ResetPassword"));

// const Nav = React.lazy(() => import(/* webpackPrefetch: true */ "./component/Nav"));

function App() {
  // const isAuth = useSelector((state) => state.login.isAuth);
  return (
    <div className="App">
      <header className="App-header">
        <React.Suspense
          fallback={
            <div className="loader">
              <div className="loaderRectangle">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
            </div>
          }
        >
<BrowserRouter  basename="/dashboard" >
            {/* {!isAuth && <Nav/>} */}
            <Routes>
              <Route path="/" element={<Login />} />
              <Route path="/dashboard/*" element={<Dashboard />} />
              <Route path="/forgotPassword/*" element={<ForgotPassword />} />
              <Route path="/resetPassword/*" element={<ResetPassword />} />
            </Routes>
          </BrowserRouter>
        </React.Suspense>
      </header>
    </div>
  );
}

export default App;






// import "./App.css";
// import { BrowserRouter, Route, Routes } from "react-router-dom";
// import React from "react";

// const Login = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/Login")
// );
// const Dashboard = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/Dashboard")
// );
// // const EmployeeMaster = React.lazy(() =>
// //   import(/* webpackPrefetch: true */ "./component/EmployeeMaster")
// // );
// const ForgotPassword = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/ForgotPassword")
// );
// const ResetPassword = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/ResetPassword")
// );

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <React.Suspense
//           fallback={
//             <div className="loader">
//               <div className="loaderRectangle">
//                 <div></div>
//                 <div></div>
//                 <div></div>
//                 <div></div>
//                 <div></div>
//               </div>
//             </div>
//           }
//         >
//           <BrowserRouter basename="/">
//             <Routes>
//               <Route path="/" element={<Login />} />
//               <Route path="/dashboard/*" element={<Dashboard />} />
//               {/* <Route path="/dashboard/employee-master" element={<EmployeeMaster />} /> */}
//               <Route path="/forgotPassword/*" element={<ForgotPassword />} />
//               <Route path="/resetPassword/*" element={<ResetPassword />} />
//             </Routes>
//           </BrowserRouter>
//         </React.Suspense>
//       </header>
//     </div>
//   );
// }

// export default App;







// import "./App.css";
// import { BrowserRouter, Routes, Route } from "react-router-dom";
// import React from "react";

// const Login = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/Login")
// );
// const Dashboard = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/Dashboard")
// );
// const EmployeeMaster = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/EmployeeMaster")
// );
// const EmployeeList = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/EmployeeList")
// );
// const ForgotPassword = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/ForgotPassword")
// );
// const ResetPassword = React.lazy(() =>
//   import(/* webpackPrefetch: true */ "./component/ResetPassword")
// );

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <React.Suspense
//           fallback={
//             <div className="loader">
//               <div className="loaderRectangle">
//                 <div></div>
//                 <div></div>
//                 <div></div>
//                 <div></div>
//                 <div></div>
//               </div>
//             </div>
//           }
//         >
//           <BrowserRouter basename="/">
//             <Routes>
//               <Route path="/" element={<Login />} />
//               <Route path="/forgotPassword/*" element={<ForgotPassword />} />
//               <Route path="/resetPassword/*" element={<ResetPassword />} />
//               {/* Dashboard layout with nested routes */}
//               <Route path="/dashboard" element={<Dashboard />}>
//                 <Route path="/dashboard/employee-master" element={<EmployeeMaster />} />
//                 <Route path="employee-list" element={<EmployeeList />} />
//                 {/* Add additional nested routes if needed */}
//               </Route>
//             </Routes>
//           </BrowserRouter>
//         </React.Suspense>
//       </header>
//     </div>
//   );
// }

// export default App;
