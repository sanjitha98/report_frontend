import React, { useState } from "react";
import './ProjectMasters.css';
import * as XLSX from "xlsx";

const ProjectMaster = () => {
  const [selectedHeadings, setSelectedHeadings] = useState([]);

  const projects = [
    {
      heading: "KST",
      subdivisions: ["Reporting Software", "Accounting Software", "Website", "School Projects", "Mobile App", "ID Card Typing"],
    },
    {
      heading: "Calcium",
      subdivisions: ["Power BI", "Azure", "Web", "Mobile", "Core Studio"],
    },
    {
      heading: "Sify",
      subdivisions: [
        "Collocation",
        "P2P",
        "DIA",
        "Cross Connect Domestic",
        "Login",
        "MPLS",
        "Colointernet",
        "GCC",
        "Channel Partner",
        "Docusign",
        "NSE",
        "Others",
      ],
    },
    {
      heading: "Brakes India",
      subdivisions: ["PMS", "Unit-1", "Unit-2", "Unit-11", "RWH", "KST"],
    },
    {
      heading: "TNPC",
      subdivisions: [
        "Building Asset Management",
        "Equipment Asset Management",
        "Fleet",
        "Billing Software",
        "Quarter Management",
      ],
    },
    {
      heading: "CRPF",
      subdivisions: ["Billing Software", "Montessori School Website"],
    },
    {
      heading: "Renault",
      subdivisions: ["VMS"],
    },
    {
      heading: "RRD",
      subdivisions: ["CMS"],
    },
    {
      heading: "Wheels India",
      subdivisions: ["CV Unit"],
    },
    {
      heading: "ID Card Scanning",
      subdivisions: [],
    },
  ];

  // Toggle subdivision display
  const toggleHeading = (heading) => {
    setSelectedHeadings((prevSelected) =>
      prevSelected.includes(heading)
        ? prevSelected.filter((h) => h !== heading)
        : [...prevSelected, heading]
    );
  };

  // Export to .xlsx file
  const exportToExcel = () => {
    const data = [];

    projects.forEach((project) => {
      if (selectedHeadings.includes(project.heading)) {
        if (project.subdivisions.length > 0) {
          project.subdivisions.forEach((sub) =>
            data.push({ Project: project.heading, Subdivision: sub })
          );
        } else {
          data.push({ Project: project.heading, Subdivision: "N/A" });
        }
      }
    });

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Projects");

    XLSX.writeFile(workbook, "Project_Master.xlsx");
  };

  return (
    <div className="p-5">
      <h2 className="text-2xl font-bold mb-4">Projects</h2>

      <div className="border p-4 rounded shadow-lg bg-white">
        {projects.map((project) => (
          <div key={project.heading} className="mb-4">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={selectedHeadings.includes(project.heading)}
                onChange={() => toggleHeading(project.heading)}
                className="mr-2"
              />
              <span className="text-lg font-semibold">{project.heading}</span>
            </label>

            {selectedHeadings.includes(project.heading) && (
              <ul className="ml-6 mt-2 list-disc">
                {project.subdivisions.map((sub, index) => (
                  <li key={index} className="text-gray-700">{sub}</li>
                ))}
              </ul>
            )}
          </div>
        ))}

        <button
          onClick={exportToExcel}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Export 
        </button>
      </div>
    </div>
  );
};

export default ProjectMaster;
